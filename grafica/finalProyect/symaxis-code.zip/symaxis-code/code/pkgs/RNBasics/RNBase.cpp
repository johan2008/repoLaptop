/* Source file for GAPS base class  */



/* Include files */

#include "RNBasics.h"



/* Global variables */

RNMark RNmark = 1;



int RNInitBase() 
{
    /* Return OK status */
    return TRUE;
}



void RNStopBase()
{
}




