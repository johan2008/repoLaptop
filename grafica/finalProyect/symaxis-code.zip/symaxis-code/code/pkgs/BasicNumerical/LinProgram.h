#include "glpk.h"

#ifndef __LIN_PROGRAM_H
#define __LIN_PROGRAM_H

class LinearProgram
{
	public:
		
};

#endif