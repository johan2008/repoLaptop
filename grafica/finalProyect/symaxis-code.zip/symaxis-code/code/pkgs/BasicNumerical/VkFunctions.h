#include <assert.h>

#ifndef __VKFUNCTIONS_H
#define __VKFUNCTIONS_H

#define vkMax(a,b) ((a)>(b)?(a):(b))

#define vkMin(a,b) ((a)<(b)?(a):(b))

#define vkAbs(a) ((a)<(0)?(-(a)):(a))

#endif


