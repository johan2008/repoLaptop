El proyecto compila con el siguiente comando:

g++ -std=c++11 main.cpp InitShader.cpp texture.c  -o main -lglut -lGLEW -lGL -lGLU && ./main


Movimiento con el teclado.

X : Movimiento hacia el eje x+
x : Movimiento hacia el eje x-
Y : Movimiento hacia el eje y+
y : Movimiento hacia el eje y-
Z : Movimiento hacia el eje z+
z : Movimiento hacia el eje z-

